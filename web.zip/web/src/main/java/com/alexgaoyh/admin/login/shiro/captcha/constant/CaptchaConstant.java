package com.alexgaoyh.admin.login.shiro.captcha.constant;

/**
 * 验证码常量
 * @author Administrator
 *
 */
public class CaptchaConstant {

	/**
	 * 验证码常量
	 */
	public static final String KEY_CAPTCHA = "SE_KEY_MM_CODE";
}

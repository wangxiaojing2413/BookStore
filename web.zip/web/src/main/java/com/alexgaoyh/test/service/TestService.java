package com.alexgaoyh.test.service;

import com.alexgaoyh.common.service.BaseService;
import com.alexgaoyh.test.entity.TestEntity;

public interface TestService extends BaseService<TestEntity>{

}
